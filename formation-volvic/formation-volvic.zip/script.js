// Configuration Supabase
const SUPABASE_URL = 'https://vwcgpclghshuvrglueqo.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ3Y2dwY2xnaHNodXZyZ2x1ZXFvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMxOTE4NTgsImV4cCI6MjA1ODc2Nzg1OH0.088dbATv--ZavX___P5tY5xCBRClTEPlBOwZElDfSK0';
const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Éléments DOM
const formulaireInscription = document.getElementById('formulaire-inscription');
const emailInput = document.getElementById('email');
const rgpdCheckbox = document.getElementById('rgpd');
const btnInscription = document.getElementById('btn-inscription');
const messageResultat = document.getElementById('message-resultat');
const compteurContainer = document.getElementById('compteur-container');

// Fonction pour afficher un message de résultat
function afficherMessage(message, type) {
    messageResultat.textContent = message;
    messageResultat.classList.remove('hidden', 'success', 'error');
    messageResultat.classList.add(type);
    
    // Masquer le message après 5 secondes
    setTimeout(() => {
        messageResultat.classList.add('hidden');
    }, 5000);
}

// Fonction pour mettre à jour le compteur
async function mettreAJourCompteur() {
    try {
        // Récupérer le nombre d'inscrits depuis Supabase
        const { count, error } = await supabase
            .from('inscriptions_volvic')
            .select('*', { count: 'exact', head: true });
            
        if (error) throw error;
        
        // Déterminer le message à afficher selon le nombre d'inscrits
        let message = '';
        let classe = '';
        
        if (count >= 12) {
            message = '🚫 Les inscriptions sont closes !';
            classe = 'compteur-ferme';
            
            // Désactiver le formulaire si les inscriptions sont closes
            formulaireInscription.querySelectorAll('input, button').forEach(element => {
                element.disabled = true;
            });
            
            // Envoyer une notification par email (simulé côté client)
            if (count === 12) {
                envoyerNotificationEmail();
            }
        } else if (count >= 10) {
            message = `⚡ Il ne reste plus beaucoup de places...`;
            classe = 'compteur-urgent';
        } else if (count >= 8) {
            message = `🔥 La formation est imminente !`;
            classe = 'compteur-imminent';
        } else {
            message = `${count} personne${count > 1 ? 's' : ''} déjà inscrite${count > 1 ? 's' : ''}.`;
            classe = 'compteur-normal';
        }
        
        // Mettre à jour l'affichage du compteur
        compteurContainer.textContent = message;
        compteurContainer.className = classe;
        
    } catch (error) {
        console.error('Erreur lors de la mise à jour du compteur:', error);
    }
}

// Fonction pour inscrire un email
async function inscrireEmail(email) {
    try {
        const { data, error } = await supabase
            .from('inscriptions_volvic')
            .insert([{ email: email }]);
            
        if (error) {
            // Vérifier si c'est une erreur de doublon (code 23505)
            if (error.code === '23505') {
                afficherMessage('⚠️ Cet email est déjà inscrit.', 'error');
            } else {
                afficherMessage('❌ Une erreur est survenue lors de l\'inscription.', 'error');
                console.error('Erreur Supabase:', error);
            }
            return false;
        }
        
        afficherMessage('✅ Inscription réussie !', 'success');
        return true;
    } catch (error) {
        afficherMessage('❌ Une erreur est survenue lors de l\'inscription.', 'error');
        console.error('Erreur:', error);
        return false;
    }
}

// Fonction pour envoyer une notification par email (simulée côté client)
// Cette fonction est maintenant définie dans notification.js

// Gestionnaire d'événement pour la soumission du formulaire
formulaireInscription.addEventListener('submit', async function(event) {
    event.preventDefault();
    
    // Vérifier que les champs sont valides
    if (!emailInput.validity.valid) {
        afficherMessage('Veuillez entrer une adresse email valide.', 'error');
        return;
    }
    
    if (!rgpdCheckbox.checked) {
        afficherMessage('Vous devez accepter les conditions RGPD pour vous inscrire.', 'error');
        return;
    }
    
    // Désactiver le bouton pendant l'inscription
    btnInscription.disabled = true;
    btnInscription.textContent = 'Inscription en cours...';
    
    // Inscrire l'email
    const inscriptionReussie = await inscrireEmail(emailInput.value);
    
    // Réactiver le bouton
    btnInscription.disabled = false;
    btnInscription.textContent = 'Je m\'inscris';
    
    // Si l'inscription a réussi, réinitialiser le formulaire et mettre à jour le compteur
    if (inscriptionReussie) {
        formulaireInscription.reset();
        mettreAJourCompteur();
    }
});

// Initialiser le compteur au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    mettreAJourCompteur();
});
